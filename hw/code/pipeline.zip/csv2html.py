import mycsv

headers, data = mycsv.readcsv(mycsv.getdata())
